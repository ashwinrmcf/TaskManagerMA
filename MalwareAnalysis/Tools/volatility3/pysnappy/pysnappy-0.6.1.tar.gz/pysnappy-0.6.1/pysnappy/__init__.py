#!/usr/bin/env python
from pysnappy.core import compress, uncompress
