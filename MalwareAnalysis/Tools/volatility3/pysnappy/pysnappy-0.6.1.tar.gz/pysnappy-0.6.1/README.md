You probably want python-snappy
